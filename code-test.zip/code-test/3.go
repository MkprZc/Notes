package main

import (
	"fmt"
	"sync"
	"context"
	"time"
)

func main() {
	var wg sync.WaitGroup
	ctx, cancel := context.WithCancel(context.Background())

	wg.Add(1)
	go func() {
		defer wg.Done()

		ch := make(chan struct{})
		go func() {
			defer close(ch)
			a := 10
			fmt.Println("子协程执行中")
			time.Sleep(10 * time.Second)
			fmt.Println(a)
		}()

		select {
		case <-ctx.Done(): // 如果context取消则直接跳出
			fmt.Println("协程被取消")
			return
		case <-ch:
			return
		}
	}()

	go func() {
		time.Sleep(2 * time.Second)
		cancel() // 取消协程
	}()

	wg.Wait()
	fmt.Println("主程序退出")
}

// 主协程取消退出导致协程也被取消退出了，如果子协程里面有很多的资源，那这些资源会被 gc 回收掉嘛