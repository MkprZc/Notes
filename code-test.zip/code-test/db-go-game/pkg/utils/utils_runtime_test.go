package utils

import "testing"

func TestGetFuncName(t *testing.T) {
	FuncName()
}
