package main

import (
	"context"
	"fmt"
	"sync"
	"time"
)

func main() {
	wait := new(sync.WaitGroup)
	wait.Add(2)

	ctx, cancel := context.WithCancel(context.Background())

	go c(cancel)

	count(ctx, wait, func() {
		fmt.Println("完成了")
	})

	fmt.Println(ctx.Value("id"))

	wait.Wait()

	fmt.Println(ctx.Value("id"))
}

func c(cancel context.CancelFunc) {
	time.Sleep(10 * time.Second)
	cancel()
}

type aa struct {
	s int
}

func count(ctx context.Context, wg *sync.WaitGroup, complement func()) {
	defer complement()

	a1 := &aa{1}
	a2 := &aa{2}
	m := map[string]*aa{
		"a1": a1,
		"a2": a2,
	}

	ctx = context.WithValue(ctx, "id", m)
	go cpu(ctx, wg)

	ctx = context.WithValue(ctx, "name", "abc")

	go mem(ctx, wg)
}

func cpu(ctx context.Context, wg *sync.WaitGroup) {
	defer wg.Done()
	for {
		select {
		case <-ctx.Done():
			fmt.Println("cpu 监控退出")
			return

		default:
			time.Sleep(2 * time.Second)
			fmt.Println("cpu 信息：", ctx.Value("id"), ctx.Value("name"))
			a := ctx.Value("id")
			aa, ok := a.(map[string]*aa)
			if ok {
				fmt.Println(aa["a1"].s)
			}
		}
	}
}

func mem(ctx context.Context, wg *sync.WaitGroup) {
	defer wg.Done()
	for {
		select {
		case <-ctx.Done():
			fmt.Println("mem 监控退出")
			return

		default:
			time.Sleep(2 * time.Second)
			fmt.Println("mem 信息：", ctx.Value("id"), ctx.Value("name"))
		}
	}
}
