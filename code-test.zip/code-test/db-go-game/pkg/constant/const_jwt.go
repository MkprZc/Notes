package constant

const (
	JWT_ISSUER           = "lark.com"
	JWT_TOKEN_SECRET_KEY = "lark_jwt_token_2022"
	JWT_PREFIX           = "jwt="
)
