package constant

const (
	USER_UID            = "uid"
	USER_PLATFORM       = "platform"
	USER_JWT_SESSION_ID = "session_id"
)
