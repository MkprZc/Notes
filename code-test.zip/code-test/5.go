package main

import (
	"fmt"
	"runtime"
	"sync"
	"time"
)

func main1() {
	runtime.GOMAXPROCS(1)
	wg := sync.WaitGroup{}
	wg.Add(2)

	go func() {
		defer wg.Done()
		i := 0
		for {
			fmt.Println("------", i)
			i++
		}

	}()

	go func() {
		defer wg.Done()
		for i := 0; i < 10; i++ {
			fmt.Println(i)
		}

		// time.Sleep(time.Second * 10)

		// panic("err")
	}()

	// time.Sleep(time.Second * 2)

	wg.Wait()
}

func main2() {
	runtime.GOMAXPROCS(1)
	// wg := sync.WaitGroup{}
	// wg.Add(2)

	go func() {
		// defer wg.Done()
		i := 0
		for {
			fmt.Println("-------------", i)
			i++
		}

	}()

	go func() {
		// defer wg.Done()
		i := 0
		for {
			fmt.Println(i)
			i++
		}
	}()

	k := 0
	for {
		k++
	}

	// time.Sleep(time.Second * 2)

	// wg.Wait()
}

func main() {
	ch := make(chan struct{})

	for i := 0; i < 3; i++ {
		go func(i int) {
			select {
			case <-ch:
				fmt.Println(i, "get")
			}
		}(i)
	}

	ch <- struct{}{}
	// close(ch)

	time.Sleep(3 * time.Second)

}
