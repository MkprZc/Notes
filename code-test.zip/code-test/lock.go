package main

import "sync"

type com struct {
	mutex *sync.Mutex

	list []int

	rwMutex *sync.RWMutex

	rMap map[string]int
}

func (c *com) setList(i int) {
	c.mutex.Lock()
	c.list = append(c.list, i)
	c.mutex.Unlock()
}

func (c *com) setMap(key string, value int) {
	c.rwMutex.RLock()
	if _, ok := c.rMap[key]; ok {
		c.rwMutex.RUnlock()
	} else {
		c.rwMutex.RUnlock()

		c.rwMutex.Lock()
		c.rMap[key] = value
		c.rwMutex.Unlock()
	}
}
