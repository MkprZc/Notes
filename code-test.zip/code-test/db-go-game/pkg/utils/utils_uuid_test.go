package utils

import (
	"fmt"
	"testing"
)

func TestGetGetUUID(t *testing.T) {
	fmt.Println(NewUUID())
}
