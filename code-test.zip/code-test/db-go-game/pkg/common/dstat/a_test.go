package dstat

import "testing"

func TestA(T *testing.T) {
	select {}
}
