package main

import (
	"fmt"
	"strconv"
	"sync"
	"testing"
)

func TestCom(t *testing.T) {
	c := &com{
		mutex: new(sync.Mutex),

		list: make([]int, 0),

		rwMutex: new(sync.RWMutex),

		rMap: make(map[string]int),
	}

	wait := new(sync.WaitGroup)
	for i := 0; i < 1000000; i++ {
		wait.Add(2)

		go func(i int) {
			defer wait.Done()
			key := strconv.FormatInt(int64(i), 10)
			c.setMap(key, i)
		}(i)

		go func(i int) {
			defer wait.Done()
			// key := strconv.FormatInt(int64(i), 10)
			c.setList(i)
		}(i)
	}

	wait.Wait()

	fmt.Println("success")

}
