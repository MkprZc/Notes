package constant

const (
	API_PUBLIC = "/api/public/"
)

const (
	HTTP_REQUEST_METHOD_POST = "POST"
	HTTP_REQUEST_METHOD_GET  = "GET"
)
