package dredis

const (
	MSG_SEQ_ID = "MSG:SEQ_ID:"
)
