package main

import (
	"fmt"
	"time"
	"sync"
	"sync/atomic"
	"testing"
)

func TestAtomic(t *testing.T) {
	var a int32 =  0
	var wg sync.WaitGroup
	start := time.Now()
	for i := 0; i < 50; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			atomic.AddInt32(&a, 1)
			fmt.Println(a)
		}()
	}
	wg.Wait()
	fmt.Println(a)
	timeSpends := time.Now().Sub(start).Nanoseconds()
	fmt.Printf("use atomic a is %d, spend time: %v\n", atomic.LoadInt32(&a), timeSpends)
}


func TestAtomic2(t *testing.T) {
	a := new(int32)
	go func() {
		for {
			*a++
		}
	}()
	time.Sleep(1 * time.Second)
	fmt.Println("a=", *a)
}