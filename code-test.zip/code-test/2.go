package main

import (
	"fmt"
	"sync"
)

func cat(wg *sync.WaitGroup, catChan, dogChan chan struct{}) {
	defer wg.Done()
	for i := 0; i < 3; i++ {
		<-catChan
		fmt.Println("cat")
		dogChan <- struct{}{}
	}
}

func dog(wg *sync.WaitGroup, dogChan, fishChan chan struct{}) {
	defer wg.Done()
	for i := 0; i < 3; i++ {
		<-dogChan
		fmt.Println("dog")
		fishChan <- struct{}{}
	}
}

func fish(wg *sync.WaitGroup, fishChan, catChan chan struct{}) {
	defer wg.Done()
	for i := 0; i < 3; i++ {
		<-fishChan
		fmt.Println("fish")
		catChan <- struct{}{}
	}
}

func main() {
	catChan := make(chan struct{}, 1)
	dogChan := make(chan struct{})
	fishChan := make(chan struct{})

	defer func() {
		close(catChan)
		close(dogChan)
		close(fishChan)
	}()

	wg := new(sync.WaitGroup)
	wg.Add(3)
	go cat(wg, catChan, dogChan)
	go dog(wg, dogChan, fishChan)
	go fish(wg, fishChan, catChan)

	catChan <- struct{}{}

	wg.Wait()

}
