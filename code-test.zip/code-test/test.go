package main

import "fmt"

func main() {

	sss := make([]int, 0, 0)

	fmt.Println(&sss[0])

	s := make([]int, 10, 12)
	s1 := s[8:]
	changeSlice(s1)
	// fmt.Printf
	fmt.Printf("s: %v, len of s: %d, cap of s: %d", s, len(s), cap(s))
	fmt.Printf("s1: %v, len of s1: %d, cap of s1: %d", s1, len(s1), cap(s1))
}

func changeSlice(s1 []int) {
	s1 = append(s1, 10)

	fmt.Println("------", len(s1), cap(s1))
}
